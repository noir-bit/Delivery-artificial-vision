#include "dl_tie728_s16.S"

    .align 4
    .text
    .global dl_tie728_s16_prelu_11c
    .type   dl_tie728_s16_prelu_11c, @function
    .section .iram1
dl_tie728_s16_prelu_11c:
    .align 4
    entry sp, 16

    # a2: int16_t *output_ptr
    # a3: int16_t *input_ptr
    # a4: void *args
    # a5: c_rs1_1: c / 2x - 1
    # a6: c_rs2_1: c_left_1
    # a14: activation_alpha_ptr
    # a15: activation_shift


    l32i a5, a4, 88
    l32i a6, a4, 92
    l32i a14, a4, 80  # activation_alpha_ptr
    l32i a15, a4, 84  # activation_shift


    loopgtz a5, 0f
        EE.VLD.128.IP q0, a3, 16
        EE.VLD.128.IP q2, a14, 16
        EE.VLD.128.IP q1, a3, 16
        EE.VLD.128.IP q3, a14, 16

        EE.VPRELU.S16 q0, q0, q2, a15
        EE.VST.128.IP q0, a2, 16

        EE.VPRELU.S16 q1, q1, q3, a15
        EE.VST.128.IP q1, a2, 16
    0:

    blti a6, 0, 5f
    loopgtz a6, 1f
        EE.VLD.128.IP q0, a3, 16
        EE.VLD.128.IP q2, a14, 16

        EE.VPRELU.S16 q0, q0, q2, a15
        EE.VST.128.IP q0, a2, 16
    1:


    EE.VLD.128.IP q0, a3, 16
    EE.VLD.128.IP q2, a14, 16

    EE.VPRELU.S16 q0, q0, q2, a15
    EE.VST.128.IP q0, a2, 16
5:
    retw




    .align 4
    .text
    .global dl_tie728_s16_unaligned_prelu_11c
    .type   dl_tie728_s16_unaligned_prelu_11c, @function
    .section .iram1
dl_tie728_s16_unaligned_prelu_11c:
    .align 4
    entry sp, 16

    # a2: int8_t *output_ptr
    # a3: int8_t *input_ptr
    # a4: void *args
    # a5: c_div_x_1
    # a6: c_remainder
    # a14: activation_alpha_ptr
    # a15: activation_shift


    l32i a5, a4, 100
    l32i a6, a4, 136
    l32i a14, a4, 80  # activation_alpha_ptr
    l32i a15, a4, 84  # activation_shift


    EE.LD.128.USAR.IP q5, a2, 0 #get output_ptr sar_byte
    rur.sar_byte a13

    blti a5, 0, dl_tie718_s16_unaligned_prelu_11c_small_remainder # channel < 16


    EE.LD.128.USAR.IP q0, a3, 16
    EE.LD.128.USAR.IP q1, a3, 16

    beqi a13, 0, dl_tie718_s16_unaligned_prelu_11c_0
    beqi a13, 8, dl_tie718_s16_unaligned_prelu_11c_1


    loopgtz a5, 0f
        EE.SRC.Q.QUP q2, q0, q1

        EE.VLD.128.IP q3, a14, 16
        EE.LD.128.USAR.IP q1, a3, 16
        EE.VPRELU.S16 q2, q2, q3, a15
        dl_tie728_128b_unaligned_store0 q2, a2, a13
    0:
    addi a3, a3, -16
    add a3, a3, a6
    rur.sar_byte a11
    EE.VLD.128.IP q3, a14, 16
    EE.SRC.Q.QUP q2, q0, q1
    EE.VPRELU.S16 q2, q2, q3, a15
    dl_tie728_128b_unaligned_store0 q2, a2, a13
    j dl_tie718_s16_unaligned_prelu_11c_remainder


dl_tie718_s16_unaligned_prelu_11c_0:
    loopgtz a5, 0f
        EE.SRC.Q.QUP q2, q0, q1

        EE.VLD.128.IP q3, a14, 16
        EE.LD.128.USAR.IP q1, a3, 16
        EE.VPRELU.S16 q2, q2, q3, a15
        EE.VST.128.IP q2, a2, 16
    0:
    addi a3, a3, -16
    add a3, a3, a6
    rur.sar_byte a11
    EE.VLD.128.IP q3, a14, 16
    EE.SRC.Q.QUP q2, q0, q1
    EE.VPRELU.S16 q2, q2, q3, a15
    EE.VST.128.IP q2, a2, 16
    j dl_tie718_s16_unaligned_prelu_11c_remainder


dl_tie718_s16_unaligned_prelu_11c_1:

    loopgtz a5, 0f
        EE.SRC.Q.QUP q2, q0, q1

        EE.VLD.128.IP q3, a14, 16
        EE.LD.128.USAR.IP q1, a3, 16
        EE.VPRELU.S16 q2, q2, q3, a15
        dl_tie728_128b_unaligned_store1 q2, a2
    0:
    addi a3, a3, -16
    add a3, a3, a6
    rur.sar_byte a11
    EE.VLD.128.IP q3, a14, 16
    EE.SRC.Q.QUP q2, q0, q1
    EE.VPRELU.S16 q2, q2, q3, a15
    dl_tie728_128b_unaligned_store1 q2, a2
    j dl_tie718_s16_unaligned_prelu_11c_remainder


dl_tie718_s16_unaligned_prelu_11c_small_remainder:
    EE.LD.128.USAR.XP q0, a3, a6
    rur.sar_byte a11


dl_tie718_s16_unaligned_prelu_11c_remainder:

    beqz a6, dl_tie728_s16_unaligned_prelu_11c_end

    EE.LD.128.USAR.IP q1, a3, 0
    wur.sar_byte a11
    EE.SRC.Q q2, q0, q1

    EE.VLD.128.IP q3, a14, 16
    EE.VPRELU.S16 q2, q2, q3, a15
    srli a6, a6, 1
    dl_tie728_s16_store_remainder q2, a6, a13, a2

dl_tie728_s16_unaligned_prelu_11c_end:
    retw
